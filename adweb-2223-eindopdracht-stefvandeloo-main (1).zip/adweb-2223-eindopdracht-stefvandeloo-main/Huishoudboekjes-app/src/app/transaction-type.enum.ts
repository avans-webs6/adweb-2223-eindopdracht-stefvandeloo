export enum TransactionType {
    INCOME="Income",
    EXPENSES="Expenses",
}
