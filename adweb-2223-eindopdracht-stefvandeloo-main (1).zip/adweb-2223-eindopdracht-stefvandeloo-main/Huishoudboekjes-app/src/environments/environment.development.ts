export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: "AIzaSyBaTDFADzWBGrf36AUiW8fYv9T9RibeM-E",
        authDomain: "adweb-2223-huishoudboekjes.firebaseapp.com",
        projectId: "adweb-2223-huishoudboekjes",
        storageBucket: "adweb-2223-huishoudboekjes.appspot.com",
        messagingSenderId: "1083409871180",
        appId: "1:1083409871180:web:30637713b059b179a49fe9",
        measurementId: "G-EM1K5V7PS7"
    },
};
